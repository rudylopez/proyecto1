#include "avl.h"

AVL::AVL()
{
    nodo.padre=-1;
    nodo.izquierdo=-1;
    nodo.derecho=-1;
    nodo.altura=-1;
}
